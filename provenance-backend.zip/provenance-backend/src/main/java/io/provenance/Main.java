package io.provenance;

import java.util.ArrayList;
import java.util.List;

import com.datastax.driver.core.BatchStatement;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.SimpleStatement;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.provenance.config.Config;
import io.provenance.controllers.helper.ControllerHelper;
import io.provenance.model.Datapoint;

public class Main {

	public static void main(String[] args) throws JsonProcessingException {
		getSession();
		String key = "amm6671251251122kj";
		
/*		StringBuilder keyspaceQueryBuilder = new StringBuilder("CREATE KEYSPACE IF NOT EXISTS ")
			      .append(key + " WITH replication = {'class':'SimpleStrategy','replication_factor':")
			      .append("1")
			      .append("}");
	    session.execute(keyspaceQueryBuilder.toString());
		StringBuilder tableQueryBuilder1 = new StringBuilder("CREATE TABLE IF NOT EXISTS " + key)
				.append(".m(uid text PRIMARY KEY, t text) ");
		session.execute(tableQueryBuilder1.toString());
		
		session.execute("CREATE CUSTOM INDEX  fn_prefix ON "+key+".m (t) ;");
		
		StringBuilder selectQueryBuilder = new StringBuilder("SELECT uid FROM ").append(key)
	    		.append(String.format(".heartbeat WHERE id = '%s' AND latest = TRUE ALLOW FILTERING", "moon"));
    	Row lastRow = session.execute(selectQueryBuilder.toString()).one();
    	BatchStatement batchStatement = new BatchStatement();

			StringBuilder tableQueryBuilder = new StringBuilder("INSERT INTO ").append(key)
	    		.append(".m(uid, t) VALUES ")
	    		.append("('moon22', 'mmm')");
		batchStatement.add(new SimpleStatement(tableQueryBuilder.toString()));
		session.execute(tableQueryBuilder.toString());*/
		
		//session.execute("UPDATE "+key+".heartbeat SET latest = false where uid in (select uid from " +key+".heartbeat where latest = FLASE)");
		
		ResultSet rs = session.execute("select * from provenancekeytest.provenancetable ");
		
		
		
		
		
		List<Row> list = rs.all();

		System.out.println("Size : " + list.size());
		
		List<Datapoint> dps = new ArrayList<Datapoint>();
		
		for(Row r : list) {
			dps.add(ControllerHelper.getDaatapoint(r));
			//System.out.println(r.toString());
		}
		System.out.println(new ObjectMapper().writeValueAsString(dps));
		
		session.close();
		cluster.close();
	}

	private static Cluster cluster ;
	private static Session session;
	
	public static Session getSession() {
		if(cluster == null) 
			cluster = Cluster.builder().addContactPoint("122.129.79.66").withPort(9042).build();
		if(session == null || session.isClosed())
			session = cluster.connect();
		return session;
	}
}
